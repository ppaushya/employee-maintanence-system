package org.empMaintanence.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.empMaintanence.model.Department;
import org.empMaintanence.model.Employee;
import org.empMaintanence.model.UserMaster;
import org.empMaintanence.model.password;



public class LoginDaoImpl implements ILoginDao {

	static final Logger logger=Logger.getLogger(LoginDaoImpl.class);
	
	@Override
	public int validlogin(UserMaster usermaster) {
		// TODO Auto-generated method stub
		
		
		if(usermaster.getUserType().compareTo("admin")==0 || usermaster.getUserType().compareTo("ADMIN")==0 )
		{
			if(usermaster.getUserId().compareTo("100")==0 && usermaster.getUserName().compareTo("mainadmin")==0 && usermaster.getUserPassword().compareTo("admin123")==0)
			{
				return 1;
			}
		}
		else if(usermaster.getUserType().compareTo("employee")==0 || usermaster.getUserType().compareTo("EMPLOYEE")==0 )
		{
		   	 String sql="select * from user_master";
		     try(Connection conn=getDbConnection())
			  {
				  PreparedStatement pst=conn.prepareStatement(sql);
				  
				  ResultSet res=pst.executeQuery();
				  
				  while(res.next())
				  {
					  if(res.getString(1).compareTo(usermaster.getUserId())==0 && res.getString(2).compareTo(usermaster.getUserName())==0 && res.getString(3).compareTo(usermaster.getUserPassword())==0)
					  {
						  return 2;
					  }
				  }
				  
				  
			  } catch (SQLException e) {
		
				  logger.error("Login Error",e);
				//e.printStackTrace();
			}
		   	 
		}
				
		return 0;
	}
	
	
	private Connection getDbConnection() {
		Connection connection=null;
		try{	
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection
					("jdbc:mysql://localhost:3306/casestudy", "root", "India123");
			return connection;
		}catch (ClassNotFoundException|SQLException e) {
			
			
			  logger.error("Connection Error",e);
			e.printStackTrace();
		}
		
		return null;
		
	}


	@Override
	public int addEmployeeDetails(Employee employee) {
		// TODO Auto-generated method stub
       
		String sql="insert into employee(emp_Id,emp_First_Name,emp_Last_Name,emp_Date_Of_Birth,Emp_Date_Of_Joining,"
				+ "Emp_dept_id,Emp_Grade,Emp_designation,Emp_Basic,Emp_Gender,Emp_Marital_status,"
				+ "Emp_home_Address,Emp_contact_Num) values(?,?,?,?,?,?,?,?,?,?,?,?,?)";
		
		String sql1="insert into user_master values(?,?,?,?)";
		
		  try(Connection conn=getDbConnection())
		  {
			  PreparedStatement pst=conn.prepareStatement(sql);
			  
			  pst.setString(1, employee.getEmpId());
			  pst.setString(2, employee.getEmpFirstName());
			  pst.setString(3, employee.getEmpLastName());
			  pst.setDate(4, Date.valueOf(employee.getEmpDateOfBirth()));
			  pst.setDate(5, Date.valueOf(employee.getEmpDateOfJoining()));
			  pst.setInt(6, employee.getEmpDeptId());
			  pst.setString(7, employee.getEmpGrade());
			  pst.setString(8, employee.getEmpDesignation());
			  pst.setInt(9, employee.getEmpBasic());
			  pst.setString(10, employee.getEmpGender());
			  pst.setString(11, employee.getEmpMaritalStatus());
			  pst.setString(12, employee.getEmpHomeAddress());
			  pst.setString(13, employee.getEmpContactNo());
			  
			  int count=pst.executeUpdate();
			  
			  if(count>0)
			  {
				  System.out.println("record inserted");
				  
				  PreparedStatement pst1=conn.prepareStatement(sql1);

				  
				  pst1.setString(1, employee.getEmpId());
				  
				  pst1.setString(2, employee.getEmpFirstName());
				  
				  String dates=employee.getEmpDateOfBirth().toString();
				  
				  String dates1[]=dates.split("-");
				  
				  String password=employee.getEmpLastName().charAt(0)+ employee.getEmpFirstName() + "@" + dates1[0]; 
				  
				  pst1.setString(3, password);
				  
				  pst1.setString(4, "employee");
				  
				  
				  int count2=pst1.executeUpdate();
				  
				  System.out.println("user id : "+employee.getEmpId());
				  System.out.println("user name : "+employee.getEmpFirstName());
				  System.out.println("user password : "+password);
				  System.out.println("user type : employee");
				  
				  
				  logger.info("Inserted Successfully");
			  return 1;
			  }
			  
			  
		  } catch (SQLException e) {
			// TODO Auto-generated catch block
			  logger.error("Insertion Error",e);
			//e.printStackTrace();
		}
		


		  
return 0;
	}


	@Override
	public void modifyfirstname() {
		// TODO Auto-generated method stub
		
		Scanner scanner=new Scanner(System.in);
		
		System.out.println("Enter the employee id");
		
		int empid=scanner.nextInt();
		
		System.out.println("Enter the name you want to replace with");
		
		String replaceName=scanner.next();
		
		String sql="update employee set emp_First_Name=? where emp_Id=?";
		
		
		  try(Connection conn=getDbConnection())
		  {
			  PreparedStatement pst=conn.prepareStatement(sql);
			  
			  pst.setString(1, replaceName);
			  pst.setInt(2, empid);

			  pst.execute();
			  
			  
		  } catch (SQLException e) {
			// TODO Auto-generated catch block
			  logger.error("Modification Error",e);
			//e.printStackTrace();
		}
	}


	@Override
	public List<Employee> findBasedOnId(String userId) {
		// TODO Auto-generated method stub
		
		List<Employee> employees=new ArrayList<>();
		
		
		
		Scanner scanner=new Scanner(System.in);
		
		System.out.println("enter the id");
		
		String id=scanner.next();
		
		String sql="select * from employee where emp_Id like ? ";
		  try(Connection conn=getDbConnection())
		  {
			  PreparedStatement pst=conn.prepareStatement(sql);
			  
			  String id1=id.replace('?', '_');
			  id1=id1.replace('*', '%');
			  pst.setString(1, id1);
			  
			  ResultSet res=pst.executeQuery();
			  
			  while(res.next())
			  {
				  Employee emp=new Employee();
				  emp.setEmpId(res.getString(1));
				  emp.setEmpFirstName(res.getString(2));
				  emp.setEmpLastName(res.getString(3));
				  emp.setEmpDateOfBirth(res.getDate(4).toLocalDate());
				  emp.setEmpDateOfJoining(res.getDate(5).toLocalDate());
				  emp.setEmpDeptId(res.getInt(6));
				  emp.setEmpGrade(res.getString(7));
				  emp.setEmpDesignation(res.getString(8));
				  emp.setEmpBasic(res.getInt(9));
				  emp.setEmpGender(res.getString(10));
				  emp.setEmpMaritalStatus(res.getString(11));
				  emp.setEmpHomeAddress(res.getString(12));
				  emp.setEmpContactNo(res.getString(13));
				  employees.add(emp);
			  }
			  
		  } catch (SQLException e) {
			// TODO Auto-generated catch block
			  logger.error("Finding Error",e);
			e.printStackTrace();
		}
		
		
		return employees;
	}

	
	@Override
	public List<Department> displayDepartmentList() {
		
		List<Department> departments= new ArrayList<>();
		
		String sql="select * from Department";
		
		try(Connection conn=getDbConnection())
		  {
			  try {
				PreparedStatement pst=conn.prepareStatement(sql);
				
				ResultSet rs= pst.executeQuery();
				
				while(rs.next())
				{
					Department dept= new Department();
					
					dept.setDeptId(rs.getInt(1));
					dept.setDeptName(rs.getString(2));
					
					departments.add(dept);
					
				}
				
				return departments;
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				 logger.error("Display Error",e);
				e.printStackTrace();
			}
		  } catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return null;
	}


	@Override
	public List<Employee> displayEmployeesList() {
		// TODO Auto-generated method stub
		
	List<Employee> employees= new ArrayList<>();
		
		String sql="select * from Employee";
		
		try(Connection conn=getDbConnection())
		  {
			  try {
				PreparedStatement pst=conn.prepareStatement(sql);
				
				ResultSet rs= pst.executeQuery();
				
				while(rs.next())
				{
					Employee emp=new Employee();
					emp.setEmpId(rs.getString(1));
					emp.setEmpFirstName(rs.getString(2));
					emp.setEmpLastName(rs.getString(3));
					emp.setEmpDateOfBirth(rs.getDate(4).toLocalDate());
					emp.setEmpDateOfJoining(rs.getDate(5).toLocalDate());
					  emp.setEmpDeptId(rs.getInt(6));
					  emp.setEmpGrade(rs.getString(7));
					  emp.setEmpDesignation(rs.getString(8));
					  emp.setEmpBasic(rs.getInt(9));
					  emp.setEmpGender(rs.getString(10));
					  emp.setEmpMaritalStatus(rs.getString(11));
					  emp.setEmpHomeAddress(rs.getString(12));
					  emp.setEmpContactNo(rs.getString(13));
					  employees.add(emp);
					
				}
				
				return employees;
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				 logger.error("Display Error",e);
				e.printStackTrace();
			}
		  } catch (SQLException e1) {
			// TODO Auto-generated catch block
			  logger.error("Display Error",e1);
			e1.printStackTrace();
		}
		
		return null;
	}


	@Override
	public List<Employee> findBasedOnFirstName(String userId) {
		List<Employee> employees=new ArrayList<>();
		
		
		
		Scanner scanner=new Scanner(System.in);
		
		System.out.println("enter the first name");
		
		String id=scanner.next();
		
		String sql="select * from employee where emp_First_Name like ? ";
		  try(Connection conn=getDbConnection())
		  {
			  PreparedStatement pst=conn.prepareStatement(sql);
			  
			  String id1=id.replace('?', '_');
			  id1=id1.replace('*', '%');
			  pst.setString(1, id1);
			  
			  ResultSet res=pst.executeQuery();
			  
			  while(res.next())
			  {
				  Employee emp=new Employee();
				  emp.setEmpId(res.getString(1));
				  emp.setEmpFirstName(res.getString(2));
				  emp.setEmpLastName(res.getString(3));
				  emp.setEmpDateOfBirth(res.getDate(4).toLocalDate());
				  emp.setEmpDateOfJoining(res.getDate(5).toLocalDate());
				  emp.setEmpDeptId(res.getInt(6));
				  emp.setEmpGrade(res.getString(7));
				  emp.setEmpDesignation(res.getString(8));
				  emp.setEmpBasic(res.getInt(9));
				  emp.setEmpGender(res.getString(10));
				  emp.setEmpMaritalStatus(res.getString(11));
				  emp.setEmpHomeAddress(res.getString(12));
				  emp.setEmpContactNo(res.getString(13));
				  employees.add(emp);
			  }
			  
		  } catch (SQLException e) {
			// TODO Auto-generated catch block
			  logger.error("Finding Error",e);
			e.printStackTrace();
		}
		
		
		return employees;
	}


	@Override
	public List<Employee> findBasedOnLastName() {
List<Employee> employees=new ArrayList<>();
		
		
		
		Scanner scanner=new Scanner(System.in);
		
		System.out.println("enter the last name");
		
		String id=scanner.next();
		
		String sql="select * from employee where emp_Last_Name like ? ";
		  try(Connection conn=getDbConnection())
		  {
			  PreparedStatement pst=conn.prepareStatement(sql);
			  
			  String id1=id.replace('?', '_');
			  id1=id1.replace('*', '%');
			  pst.setString(1, id1);
			  
			  ResultSet res=pst.executeQuery();
			  
			  while(res.next())
			  {
				  Employee emp=new Employee();
				  emp.setEmpId(res.getString(1));
				  emp.setEmpFirstName(res.getString(2));
				  emp.setEmpLastName(res.getString(3));
				  emp.setEmpDateOfBirth(res.getDate(4).toLocalDate());
				  emp.setEmpDateOfJoining(res.getDate(5).toLocalDate());
				  emp.setEmpDeptId(res.getInt(6));
				  emp.setEmpGrade(res.getString(7));
				  emp.setEmpDesignation(res.getString(8));
				  emp.setEmpBasic(res.getInt(9));
				  emp.setEmpGender(res.getString(10));
				  emp.setEmpMaritalStatus(res.getString(11));
				  emp.setEmpHomeAddress(res.getString(12));
				  emp.setEmpContactNo(res.getString(13));
				  employees.add(emp);
			  }
			  
		  } catch (SQLException e) {
			// TODO Auto-generated catch block
			  logger.error("Finding Error",e);
			e.printStackTrace();
		}
		
		
		return employees;
	}


	@Override
	public List<Employee> findBasedOnDepartment() {
List<Employee> employees=new ArrayList<>();
		
		
		
		Scanner scanner=new Scanner(System.in);
		
		System.out.println("enter the department id");
		
		String id=scanner.next();
		
		String sql="select * from employee where Emp_dept_id like ? ";
		  try(Connection conn=getDbConnection())
		  {
			  PreparedStatement pst=conn.prepareStatement(sql);
			  
			  String id1=id.replace('?', '_');
			  id1=id1.replace('*', '%');
			  
			  int id2=Integer.parseInt(id1);
			  
			  pst.setInt(1, id2);
			  
			  ResultSet res=pst.executeQuery();
			  
			  while(res.next())
			  {
				  Employee emp=new Employee();
				  emp.setEmpId(res.getString(1));
				  emp.setEmpFirstName(res.getString(2));
				  emp.setEmpLastName(res.getString(3));
				  emp.setEmpDateOfBirth(res.getDate(4).toLocalDate());
				  emp.setEmpDateOfJoining(res.getDate(5).toLocalDate());
				  emp.setEmpDeptId(res.getInt(6));
				  emp.setEmpGrade(res.getString(7));
				  emp.setEmpDesignation(res.getString(8));
				  emp.setEmpBasic(res.getInt(9));
				  emp.setEmpGender(res.getString(10));
				  emp.setEmpMaritalStatus(res.getString(11));
				  emp.setEmpHomeAddress(res.getString(12));
				  emp.setEmpContactNo(res.getString(13));
				  employees.add(emp);
			  }
			  
		  } catch (SQLException e) {
			// TODO Auto-generated catch block
			  logger.error("Finding Error",e);
			e.printStackTrace();
		}
		
		
		return employees;
	}


	@Override
	public List<Employee> findBasedOnGrade() {
List<Employee> employees=new ArrayList<>();
		
		
		
		Scanner scanner=new Scanner(System.in);
		
		System.out.println("enter the grade");
		
		String id=scanner.next();
		
		String sql="select * from employee where Emp_Grade like ? ";
		  try(Connection conn=getDbConnection())
		  {
			  PreparedStatement pst=conn.prepareStatement(sql);
			  
			  String id1=id.replace('?', '_');
			  id1=id1.replace('*', '%');
			  pst.setString(1, id1);
			  
			  ResultSet res=pst.executeQuery();
			  
			  while(res.next())
			  {
				  Employee emp=new Employee();
				  emp.setEmpId(res.getString(1));
				  emp.setEmpFirstName(res.getString(2));
				  emp.setEmpLastName(res.getString(3));
				  emp.setEmpDateOfBirth(res.getDate(4).toLocalDate());
				  emp.setEmpDateOfJoining(res.getDate(5).toLocalDate());
				  emp.setEmpDeptId(res.getInt(6));
				  emp.setEmpGrade(res.getString(7));
				  emp.setEmpDesignation(res.getString(8));
				  emp.setEmpBasic(res.getInt(9));
				  emp.setEmpGender(res.getString(10));
				  emp.setEmpMaritalStatus(res.getString(11));
				  emp.setEmpHomeAddress(res.getString(12));
				  emp.setEmpContactNo(res.getString(13));
				  employees.add(emp);
			  }
			  
		  } catch (SQLException e) {
			// TODO Auto-generated catch block
			  logger.error("Finding Error",e);
			e.printStackTrace();
		}
		
		
		return employees;
	}


	@Override
	public List<Employee> findBasedOnMaritalStatus() {
List<Employee> employees=new ArrayList<>();
		
		
		
		Scanner scanner=new Scanner(System.in);
		
		System.out.println("enter the marital status");
		
		String id=scanner.next();
		
		String sql="select * from employee where Emp_Marital_status like ? ";
		  try(Connection conn=getDbConnection())
		  {
			  PreparedStatement pst=conn.prepareStatement(sql);
			  
			  String id1=id.replace('?', '_');
			  id1=id1.replace('*', '%');
			  pst.setString(1, id1);
			  
			  ResultSet res=pst.executeQuery();
			  
			  while(res.next())
			  {
				  Employee emp=new Employee();
				  emp.setEmpId(res.getString(1));
				  emp.setEmpFirstName(res.getString(2));
				  emp.setEmpLastName(res.getString(3));
				  emp.setEmpDateOfBirth(res.getDate(4).toLocalDate());
				  emp.setEmpDateOfJoining(res.getDate(5).toLocalDate());
				  emp.setEmpDeptId(res.getInt(6));
				  emp.setEmpGrade(res.getString(7));
				  emp.setEmpDesignation(res.getString(8));
				  emp.setEmpBasic(res.getInt(9));
				  emp.setEmpGender(res.getString(10));
				  emp.setEmpMaritalStatus(res.getString(11));
				  emp.setEmpHomeAddress(res.getString(12));
				  emp.setEmpContactNo(res.getString(13));
				  employees.add(emp);
			  }
			  
		  } catch (SQLException e) {
			// TODO Auto-generated catch block
			  logger.error("Finding Error",e);
			e.printStackTrace();
		}
		
		
		return employees;
	}


	@Override
	public boolean storePassword(password pass) {
		// TODO Auto-generated method stub
		
		String sql="insert into forgotpassword values(?,?,?,?)";
		
		  try(Connection conn=getDbConnection())
		  {
			  PreparedStatement pst=conn.prepareStatement(sql);
			  
			  pst.setString(1, pass.getNickName());
			  pst.setString(2, pass.getSchool());
			  pst.setString(3, pass.getFatherProfession());
			  pst.setString(4, pass.getHobby());
			  
			  int count=pst.executeUpdate();
			  
			  return true;
		  } catch (SQLException e) {
			// TODO Auto-generated catch block
			  logger.error("Password Storing Error",e);
			e.printStackTrace();
		}
		
		
		
		return false;
	}


	@Override
	public String verifyPassword(password pass, String userId) {
		// TODO Auto-generated method stub
		
		String sql="select * from forgotpassword";
		
		String sql1="select * from user_master";
		
		  try(Connection conn=getDbConnection())
		  {
			  PreparedStatement pst=conn.prepareStatement(sql);
			  
			   ResultSet res=pst.executeQuery();
			   
			   while(res.next())
			   {
				   if(res.getString(1).compareTo(pass.getNickName())==0 
						   && res.getString(2).compareTo(pass.getSchool())==0
						   && res.getString(3).compareTo(pass.getFatherProfession())==0
						   && res.getString(4).compareTo(pass.getHobby())==0)
				   {
						  PreparedStatement pst1=conn.prepareStatement(sql1);
						  
						  
						  ResultSet res2=pst1.executeQuery();

						  while(res2.next())
						  {
							  if(res2.getString(1).compareTo(userId)==0)
							  {
								  return res2.getString(3);
							  }
						  }
						  
						  
				   }
				   
			   }
			  
			  
		  } catch (SQLException e) {
			// TODO Auto-generated catch block
			  
			  logger.error("Verification Error",e);  
			e.printStackTrace();
		}
		  
		
		
		return null;
	}
	@Override
	public void modifyLastName() {
Scanner scanner=new Scanner(System.in);
		
		System.out.println("Enter the employee id");
		
		int empid=scanner.nextInt();
		
		System.out.println("Enter the  last name you want to replace with");
		
		String replaceLastName=scanner.next();
		
		String sql="update employee set emp_Last_Name=? where emp_Id=?";
		
		
		  try(Connection conn=getDbConnection())
		  {
			  PreparedStatement pst=conn.prepareStatement(sql);
			  
			  pst.setString(1, replaceLastName);
			  pst.setInt(2, empid);

			  pst.execute();
			  
			  
		  } catch (SQLException e) {
			
			e.printStackTrace();
		}
		
	}


	@Override
	public void modifyDateOfBirth() {
    Scanner scanner=new Scanner(System.in);
		
		System.out.println("Enter the employee id");
		
		int empid=scanner.nextInt();
		
		System.out.println("Enter the date of birth you want to replace with");
		
		String replaceDOB=scanner.next();
		
		String sql="update employee set emp_Date_Of_Birth=? where emp_Id=?";
		
		
		  try(Connection conn=getDbConnection())
		  {
			  PreparedStatement pst=conn.prepareStatement(sql);
			  
			/////  pst.setDate(1,replaceDOB);
			  pst.setInt(2, empid);

			  pst.execute();
			  
			  
		  } catch (SQLException e) {
			
			e.printStackTrace();
		}		
	}


	@Override
	public void modifyDateOfJoining() {
		 Scanner scanner=new Scanner(System.in);
			
			System.out.println("Enter the employee id");
			
			int empid=scanner.nextInt();
			
			System.out.println("Enter the date of joining you want to replace with");
			
			String replaceDOJ=scanner.next();
			
			String sql="update employee set emp_Date_Of_Joining=? where emp_Id=?";
			
			
			  try(Connection conn=getDbConnection())
			  {
				  PreparedStatement pst=conn.prepareStatement(sql);
				  
				/////  pst.setDate(1,replaceDOJ);
				  pst.setInt(2, empid);

				  pst.execute();
				  
				  
			  } catch (SQLException e) {
				
				e.printStackTrace();
			}	
		
		
	}


	@Override
	public void modifyDepartmentId() {
		 Scanner scanner=new Scanner(System.in);
			
			System.out.println("Enter the employee id");
			
			int empid=scanner.nextInt();
			
			System.out.println("Enter the Department ID you want to replace with");
			
			int replaceDeptId=scanner.nextInt();
			
			String sql="update employee set emp_Dept_id=? where emp_Id=?";
			
			
			  try(Connection conn=getDbConnection())
			  {
				  PreparedStatement pst=conn.prepareStatement(sql);
				  
				  pst.setInt(1, replaceDeptId);
				  pst.setInt(2, empid);

				  pst.execute();
				  
				  
			  } catch (SQLException e) {
				
				e.printStackTrace();
			}	
		
	}


	@Override
	public void modifyEmployeeGrade() {
		 Scanner scanner=new Scanner(System.in);
			
			System.out.println("Enter the employee id");
			
			int empid=scanner.nextInt();
			
			System.out.println("Enter the Employee Grade you want to replace with");
			
			String replaceGrade=scanner.next();
			
			String sql="update employee set emp_Grade=? where emp_Id=?";
			
			
			  try(Connection conn=getDbConnection())
			  {
				  PreparedStatement pst=conn.prepareStatement(sql);
				  
				  pst.setString(1, replaceGrade);
				  pst.setInt(2, empid);

				  pst.execute();
				  
				  
			  } catch (SQLException e) {
				
				e.printStackTrace();
			}	
		
	}


	@Override
	public void modifyDesignation() {
		 Scanner scanner=new Scanner(System.in);
			
			System.out.println("Enter the employee id");
			
			int empid=scanner.nextInt();
			
			System.out.println("Enter the Designation you want to replace with");
			
			String replaceDesignation=scanner.next();
			
			String sql="update employee set emp_Designation=? where emp_Id=?";
			
			
			  try(Connection conn=getDbConnection())
			  {
				  PreparedStatement pst=conn.prepareStatement(sql);
				  
				  pst.setString(1, replaceDesignation);
				  pst.setInt(2, empid);

				  pst.execute();
				  
				  
			  } catch (SQLException e) {
				
				e.printStackTrace();
			}	
		
	}


	@Override
	public void modifyBasic() {
		 Scanner scanner=new Scanner(System.in);
			
			System.out.println("Enter the employee id");
			
			int empid=scanner.nextInt();
			
			System.out.println("Enter the Basic you want to replace with");
			
			int replaceBasic=scanner.nextInt();
			
			String sql="update employee set emp_Basic=? where emp_Id=?";
			
			
			  try(Connection conn=getDbConnection())
			  {
				  PreparedStatement pst=conn.prepareStatement(sql);
				  
				  pst.setInt(1, replaceBasic);
				  pst.setInt(2, empid);

				  pst.execute();
				  
				  
			  } catch (SQLException e) {
				
				e.printStackTrace();
			}	
		
	}


	@Override
	public void modifyGender() {
		 Scanner scanner=new Scanner(System.in);
			
			System.out.println("Enter the employee id");
			
			int empid=scanner.nextInt();
			
			System.out.println("Enter the Gender you want to replace with");
			
			String replaceGender=scanner.next();
			
			String sql="update employee set emp_Gender=? where emp_Id=?";
			
			
			  try(Connection conn=getDbConnection())
			  {
				  PreparedStatement pst=conn.prepareStatement(sql);
				  
				  pst.setString(1, replaceGender);
				  pst.setInt(2, empid);

				  pst.execute();
				  
				  
			  } catch (SQLException e) {
				
				e.printStackTrace();
			}	
		
	}


	@Override
	public void modifyMaritalStatus() {
		Scanner scanner=new Scanner(System.in);
		
		System.out.println("Enter the employee id");
		
		int empid=scanner.nextInt();
		
		System.out.println("Enter the Marital Status you want to replace with");
		
		String replaceMaritalStatus=scanner.next();
		
		String sql="update employee set emp_Marital_Status=? where emp_Id=?";
		
		
		  try(Connection conn=getDbConnection())
		  {
			  PreparedStatement pst=conn.prepareStatement(sql);
			  
			  pst.setString(1, replaceMaritalStatus);
			  pst.setInt(2, empid);

			  pst.execute();
			  
			  
		  } catch (SQLException e) {
			
			e.printStackTrace();
		}	
		
	}


	@Override
	public void modifyHomeAddress() {
		Scanner scanner=new Scanner(System.in);
		
		System.out.println("Enter the employee id");
		
		int empid=scanner.nextInt();
		
		System.out.println("Enter the Home Address you want to replace with");
		
		String replaceHomeAddress=scanner.next();
		
		String sql="update employee set emp_Home_address=? where emp_Id=?";
		
		
		  try(Connection conn=getDbConnection())
		  {
			  PreparedStatement pst=conn.prepareStatement(sql);
			  
			  pst.setString(1, replaceHomeAddress);
			  pst.setInt(2, empid);

			  pst.execute();
			  
			  
		  } catch (SQLException e) {
			
			e.printStackTrace();
		}	
		
	}


	@Override
	public void modifyContactNo() {
		Scanner scanner=new Scanner(System.in);
		
		System.out.println("Enter the employee id");
		
		int empid=scanner.nextInt();
		
		System.out.println("Enter the Contact Number you want to replace with");
		
		String replaceContactNo=scanner.next();
		
		String sql="update employee set emp_Contact_num=? where emp_Id=?";
		
		
		  try(Connection conn=getDbConnection())
		  {
			  PreparedStatement pst=conn.prepareStatement(sql);
			  
			  pst.setString(1, replaceContactNo);
			  pst.setInt(2, empid);

			  pst.execute();
			  
			  
		  } catch (SQLException e) {
			
			e.printStackTrace();
		}	
		
	}


	@Override
	public String changePassword(String userId) {
		// TODO Auto-generated method stub
		
		Scanner scanner=new Scanner(System.in);
		
		System.out.println("enter ur current password");
		
		String current=scanner.next();
		
		System.out.println("enter new password");
		
		String newpassword=scanner.next();
		
		
		String sql="select * from user_master";
		
		String sql1="update user_master set userPassword=? where userId=?";


		  try(Connection conn=getDbConnection())
		  {
			  PreparedStatement pst=conn.prepareStatement(sql);
			  
			  
			  ResultSet res=pst.executeQuery();
			  
			  while(res.next())
			  {
				  if(res.getString(3).compareTo(current)==0)
				  {
					  
					  PreparedStatement pst1=conn.prepareStatement(sql1);
					  
					  pst1.setString(1, newpassword);
					  pst1.setString(2, userId);
					  
					  
					  int count=pst1.executeUpdate();
					  
					  return newpassword;
				  }
			  }
			  
			  
		  } catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}
}
