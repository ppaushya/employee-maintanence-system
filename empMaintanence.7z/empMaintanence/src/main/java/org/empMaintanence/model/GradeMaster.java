package org.empMaintanence.model;

public class GradeMaster {

	
	/*
	 * iv.	Grade_Master: Grade_Code VARCHAR2(2),
	 *  Description VARCHAR2(10), Min_Salary int, Max_Salary int
	 */
	
	private String gradeCode;
	
	private String gradeDescription;
	
	private int minSalary;
	
	private int maxSalary;

	public String getGradeCode() {
		return gradeCode;
	}

	public void setGradeCode(String gradeCode) {
		this.gradeCode = gradeCode;
	}

	public String getGradeDescription() {
		return gradeDescription;
	}

	public void setGradeDescription(String gradeDescription) {
		this.gradeDescription = gradeDescription;
	}

	public int getMinSalary() {
		return minSalary;
	}

	public void setMinSalary(int minSalary) {
		this.minSalary = minSalary;
	}

	public int getMaxSalary() {
		return maxSalary;
	}

	public void setMaxSalary(int maxSalary) {
		this.maxSalary = maxSalary;
	}

	@Override
	public String toString() {
		return "GradeMaster [gradeCode=" + gradeCode + ", gradeDescription=" + gradeDescription + ", minSalary="
				+ minSalary + ", maxSalary=" + maxSalary + "]";
	}

	public GradeMaster(String gradeCode, String gradeDescription, int minSalary, int maxSalary) {
		super();
		this.gradeCode = gradeCode;
		this.gradeDescription = gradeDescription;
		this.minSalary = minSalary;
		this.maxSalary = maxSalary;
	}

	public GradeMaster() {
		super();
	}
	
	
	
}
