package org.empMaintanence.service;

import java.util.List;

import org.empMaintanence.dao.ILoginDao;
import org.empMaintanence.dao.LoginDaoImpl;
import org.empMaintanence.model.Department;
import org.empMaintanence.model.Employee;
import org.empMaintanence.model.UserMaster;
import org.empMaintanence.model.password;

public class LoginServicesImpl implements ILoginService  {

	//CREATING REFERENCE FOR DAO LAYER FOR INTERACTION
	ILoginDao logindao=new LoginDaoImpl();
	
	public LoginServicesImpl(LoginDaoImpl logindao2) {

		
		this.logindao=logindao2;
	}
	
	

	public LoginServicesImpl() {
		super();
	}



	@Override
	public int validlogin(UserMaster usermaster) {
		// TODO Auto-generated method stub
		return logindao.validlogin(usermaster);
		
		
	}

	@Override
	public int addEmployeeDetails(Employee employee) {
		// TODO Auto-generated method stub
	      return logindao.addEmployeeDetails(employee);
	}

	@Override
	public void modifyfirstname() {
		// TODO Auto-generated method stub
		logindao.modifyfirstname();
	}

	@Override
	public List<Employee> findBasedOnId(String userId) {
		// TODO Auto-generated method stub
		return logindao.findBasedOnId(userId);
	}
	@Override
	public List<Department> displayDepartmentList() {
		
		return logindao.displayDepartmentList();
	}

	@Override
	public List<Employee> displayEmployeesList() {
		// TODO Auto-generated method stub
		return logindao.displayEmployeesList();
	}

	@Override
	public List<Employee> findBasedOnFirstName(String userId) {
		// TODO Auto-generated method stub
		return logindao.findBasedOnFirstName(userId);
	}

	@Override
	public List<Employee> findBasedOnLastName() {
		// TODO Auto-generated method stub
		return logindao.findBasedOnLastName();
	}

	@Override
	public List<Employee> findBasedOnDepartment() {
		// TODO Auto-generated method stub
		return logindao.findBasedOnDepartment();
	}

	@Override
	public List<Employee> findBasedOnGrade() {
		// TODO Auto-generated method stub
		return logindao.findBasedOnGrade();
	}

	@Override
	public List<Employee> findBasedOnMaritalStatus() {
		// TODO Auto-generated method stub
		return logindao.findBasedOnMaritalStatus();
	}

	@Override
	public boolean storePassword(password pass) {
		// TODO Auto-generated method stub
		return logindao.storePassword(pass);
	}

	@Override
	public String verifyPassword(password pass, String userId) {
		// TODO Auto-generated method stub
		return logindao.verifyPassword(pass,userId);
	}
	
	@Override
	public void modifyLastName() {
		logindao.modifyLastName();
		
	}


	@Override
	public void modifyDateOfBirth() {
		logindao.modifyDateOfBirth();
		
	}


	@Override
	public void modifyDateOfJoining() {
		logindao.modifyDateOfJoining();
		
	}


	@Override
	public void modifyDepartmentId() {
		logindao.modifyDepartmentId();
		
	}


	@Override
	public void modifyEmployeeGrade() {
		logindao.modifyEmployeeGrade();
		
	}


	@Override
	public void modifyDesignation() {
		logindao.modifyDesignation();
		
	}


	@Override
	public void modifyBasic() {
		logindao.modifyBasic();
		
	}


	@Override
	public void modifyGender() {
		logindao.modifyGender();
		
	}


	@Override
	public void modifyMaritalStatus() {
		logindao.modifyMaritalStatus();
		
	}


	@Override
	public void modifyHomeAddress() {
		logindao.modifyHomeAddress();
		
	}


	@Override
	public void modifyContactNo() {
		logindao.modifyContactNo();
		
	}



	@Override
	public String changePassword(String userId) {
		// TODO Auto-generated method stub
		
		return logindao.changePassword(userId);
		
		
	}

}
