package org.empMaintanence.service;

import java.util.List;

import org.empMaintanence.model.Department;
import org.empMaintanence.model.Employee;
import org.empMaintanence.model.UserMaster;
import org.empMaintanence.model.password;

public interface ILoginService {

	int validlogin(UserMaster usermaster);

	int addEmployeeDetails(Employee employee);
	
    void modifyfirstname();
	
    void modifyLastName();
	
	void modifyDateOfBirth();
	
	void modifyDateOfJoining();
	
	void modifyDepartmentId();
	
	void modifyEmployeeGrade();
	
	void modifyDesignation();
	
	void modifyBasic();
	
	void modifyGender();
	
	void modifyMaritalStatus();
	
	void modifyHomeAddress();
	
	void modifyContactNo();


	List<Employee> findBasedOnId(String userId);
	
	public List<Department> displayDepartmentList();

	List<Employee> displayEmployeesList();

	List<Employee> findBasedOnFirstName(String userId);

	List<Employee> findBasedOnLastName();

	List<Employee> findBasedOnDepartment();

	List<Employee> findBasedOnGrade();

	List<Employee> findBasedOnMaritalStatus();

	boolean storePassword(password pass);

	String verifyPassword(password pass, String userId);

	String changePassword(String userId);

	boolean verifyEmpId(String empId);

	
	
	
}
